import numpy as np


from .Approximant_NN import Approximant_NN
from .NN import NN

from .aux_functions import *


